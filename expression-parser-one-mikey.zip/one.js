"use strict";
/*
 *
 * ONE - A compiler for the ONE programming language
 * Copyright (C) 2022
 * Author:	Max Base
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// --- General Helper function ---
function assert(predicate) {
    if (!predicate)
        throw new Error("Assertion failure");
    return;
}
class Input {
    constructor(file, path) {
        this.file = null;
        this.path = null;
        this.data = "";
        this.file = file || null;
        this.path = path || null;
    }
    setData(data) {
        this.data = data;
    }
    readFile() {
        if (this.file && this.path) {
            const full_path = this.path + path.sep + this.file;
            if (fs.existsSync(full_path)) {
                this.data = fs.readFileSync(full_path, "utf8");
            }
            else {
                throw new Error(`File ${full_path} does not exist`);
            }
        }
    }
}
var TokenType;
(function (TokenType) {
    TokenType[TokenType["T_ERROR"] = -1] = "T_ERROR";
    TokenType[TokenType["T_EOF"] = 0] = "T_EOF";
    TokenType[TokenType["T_WHITESPACE"] = 1] = "T_WHITESPACE";
    TokenType[TokenType["T_IDENTIFIER"] = 2] = "T_IDENTIFIER";
    TokenType[TokenType["T_NUMBER"] = 3] = "T_NUMBER";
    TokenType[TokenType["T_SEMICOLON"] = 4] = "T_SEMICOLON";
    TokenType[TokenType["T_COMMA"] = 5] = "T_COMMA";
    TokenType[TokenType["T_PARENTHESIS_OPEN"] = 6] = "T_PARENTHESIS_OPEN";
    TokenType[TokenType["T_PARENTHESIS_CLOSE"] = 7] = "T_PARENTHESIS_CLOSE";
    TokenType[TokenType["T_OPEN_BRACE"] = 8] = "T_OPEN_BRACE";
    TokenType[TokenType["T_CLOSE_BRACE"] = 9] = "T_CLOSE_BRACE";
    TokenType[TokenType["T_OPERATOR_PLUS"] = 10] = "T_OPERATOR_PLUS";
    TokenType[TokenType["T_OPERATOR_MINUS"] = 11] = "T_OPERATOR_MINUS";
    TokenType[TokenType["T_OPERATOR_MULTIPLY"] = 12] = "T_OPERATOR_MULTIPLY";
    TokenType[TokenType["T_OPERATOR_DIVIDE"] = 13] = "T_OPERATOR_DIVIDE";
    TokenType[TokenType["T_OPERATOR_EQUAL"] = 14] = "T_OPERATOR_EQUAL";
    TokenType[TokenType["T_OPERATOR_DOT"] = 15] = "T_OPERATOR_DOT";
    TokenType[TokenType["T_OPERATOR_COLON"] = 16] = "T_OPERATOR_COLON";
    TokenType[TokenType["T_OPERATOR_QUESTION"] = 17] = "T_OPERATOR_QUESTION";
    TokenType[TokenType["T_OPERATOR_BANG"] = 18] = "T_OPERATOR_BANG";
    TokenType[TokenType["T_OPERATOR_POWER"] = 19] = "T_OPERATOR_POWER";
    // >
    // <
    // >=
    // <=
    // ==
    // !=
    // &&
    // ||
    // !
    TokenType[TokenType["T_OPERATOR_GREATER"] = 16] = "T_OPERATOR_GREATER";
    TokenType[TokenType["T_OPERATOR_LESS"] = 17] = "T_OPERATOR_LESS";
    TokenType[TokenType["T_OPERATOR_GREATER_EQUAL"] = 18] = "T_OPERATOR_GREATER_EQUAL";
    TokenType[TokenType["T_OPERATOR_LESS_EQUAL"] = 19] = "T_OPERATOR_LESS_EQUAL";
    TokenType[TokenType["T_OPERATOR_EQUAL_EQUAL"] = 20] = "T_OPERATOR_EQUAL_EQUAL";
    TokenType[TokenType["T_OPERATOR_NOT_EQUAL"] = 21] = "T_OPERATOR_NOT_EQUAL";
    TokenType[TokenType["T_OPERATOR_AND"] = 22] = "T_OPERATOR_AND";
    TokenType[TokenType["T_OPERATOR_OR"] = 23] = "T_OPERATOR_OR";
    TokenType[TokenType["T_OPERATOR_NOT"] = 24] = "T_OPERATOR_NOT";
    TokenType[TokenType["T_ECHO"] = 25] = "T_ECHO";
    TokenType[TokenType["T_IF"] = 26] = "T_IF";
    TokenType[TokenType["T_ELSE"] = 27] = "T_ELSE";
    TokenType[TokenType["T_FOR"] = 28] = "T_FOR";
    TokenType[TokenType["T_DO"] = 29] = "T_DO";
    TokenType[TokenType["T_WHILE"] = 30] = "T_WHILE";
    TokenType[TokenType["T_RETURN"] = 31] = "T_RETURN";
})(TokenType || (TokenType = {}));
class Token {
    constructor(type, location, value) {
        this.type = type;
        this.kind = TokenType[type];
        this.location = location;
        this.value = value;
    }
    print() {
        return `Token(${this.kind})`;
    }
}
class LocationInfo {
    constructor(start_location, end_location) {
        this.start_location = start_location || new Location(0, 0, 1);
        this.end_location = end_location || new Location(0, 0, 1);
    }
}
class Location {
    constructor(index, offset, line) {
        this.index = 0;
        this.offset = 0;
        this.line = 1;
        this.index = index;
        this.offset = offset;
        this.line = line;
    }
    deep() {
        return new Location(this.index, this.offset, this.line);
    }
}
class Lexer {
    constructor(input) {
        this.tokens = [];
        this.reservedWords = {
            "if": TokenType.T_IF,
            "else": TokenType.T_ELSE,
            "for": TokenType.T_FOR,
            "do": TokenType.T_DO,
            "while": TokenType.T_WHILE,
            "return": TokenType.T_RETURN,
            "echo": TokenType.T_ECHO,
        };
        this.location = new LocationInfo();
        this.input = input;
        if (!this.input.data) {
            throw new Error("No input data");
        }
        this.tokenize();
    }
    tokenize() {
        while (!this.isEOF()) {
            this.location.start_location = this.location.end_location.deep();
            const token = this.nextToken();
            this.tokens.push(token);
        }
        this.location.start_location = new Location(0, 0, 1);
    }
    nextIndex(n) {
        this.location.end_location.offset += n;
        this.location.end_location.index += n;
    }
    getLocation() {
        return new LocationInfo(this.location.start_location.deep(), this.location.end_location.deep());
    }
    createToken(kind, value) {
        return new Token(kind, this.getLocation(), value);
    }
    nextToken() {
        let c = this.getChar();
        if (c === null) {
            return this.createToken(TokenType.T_EOF);
        }
        if (this.isWhitespace(c)) {
            return this.readWhitespace();
        }
        if (c === ";") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_SEMICOLON);
        }
        if (c === "+") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_PLUS);
        }
        if (c === "-") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_MINUS);
        }
        if (c === "*") {
            this.nextIndex(1);
            if (this.getChar() === "*") {
                this.nextIndex(1);
                return this.createToken(TokenType.T_OPERATOR_POWER);
            }
            return this.createToken(TokenType.T_OPERATOR_MULTIPLY);
        }
        if (c === "/") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_DIVIDE);
        }
        if (c === ".") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_DOT);
        }
        if (c === ":") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_COLON);
        }
        if (c === "?") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPERATOR_QUESTION);
        }
        if (c === "(") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_PARENTHESIS_OPEN);
        }
        if (c === ")") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_PARENTHESIS_CLOSE);
        }
        if (c === "{") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_OPEN_BRACE);
        }
        if (c === "}") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_CLOSE_BRACE);
        }
        // T_OPERATOR_GREATER = 16,
        // T_OPERATOR_LESS = 17,
        // T_OPERATOR_GREATER_EQUAL = 18,
        // T_OPERATOR_LESS_EQUAL = 19,
        // T_OPERATOR_EQUAL_EQUAL = 20,
        // T_OPERATOR_NOT_EQUAL = 21,
        // T_OPERATOR_AND = 22,
        // T_OPERATOR_OR = 23,
        // T_OPERATOR_NOT = 24,
        if (c === ">") {
            this.nextIndex(1);
            if (this.getChar() === "=") {
                this.nextIndex(1);
                return this.createToken(TokenType.T_OPERATOR_GREATER_EQUAL);
            }
            return this.createToken(TokenType.T_OPERATOR_GREATER);
        }
        if (c === "<") {
            this.nextIndex(1);
            if (this.getChar() === "=") {
                this.nextIndex(1);
                return this.createToken(TokenType.T_OPERATOR_LESS_EQUAL);
            }
            return this.createToken(TokenType.T_OPERATOR_LESS);
        }
        if (c === "=") {
            this.nextIndex(1);
            if (this.getChar() === "=") {
                this.nextIndex(1);
                return this.createToken(TokenType.T_OPERATOR_EQUAL_EQUAL);
            }
            return this.createToken(TokenType.T_OPERATOR_EQUAL);
        }
        if (c === "!") {
            this.nextIndex(1);
            if (this.getChar() === "=") {
                this.nextIndex(1);
                return this.createToken(TokenType.T_OPERATOR_NOT_EQUAL);
            }
            return this.createToken(TokenType.T_OPERATOR_NOT);
        }
        if (c === ",") {
            this.nextIndex(1);
            return this.createToken(TokenType.T_COMMA);
        }
        if (this.isDigit(c)) {
            return this.readNumber();
        }
        if (this.isAlpha(c)) {
            return this.readIdentifier();
        }
        return this.createToken(TokenType.T_ERROR, `Unexpected character ${c}`);
    }
    isDigit(c) {
        return c >= "0" && c <= "9";
    }
    isAlpha(c) {
        return c >= "a" && c <= "z" || c >= "A" && c <= "Z" || c === "_";
    }
    readNumber() {
        let number = "";
        let c = this.getChar();
        while (c !== null && this.isDigit(c)) {
            number += c;
            c = this.nextChar();
        }
        return this.createToken(TokenType.T_NUMBER, number);
    }
    readIdentifier() {
        let c = this.getChar();
        let identifier = "";
        while (c !== null && this.isAlpha(c)) {
            identifier += c;
            c = this.nextChar();
        }
        if (this.reservedWords[identifier]) {
            return this.createToken(this.reservedWords[identifier]);
        }
        return this.createToken(TokenType.T_IDENTIFIER, identifier);
    }
    getChar() {
        if (this.location.end_location.index >= this.input.data.length) {
            return null;
        }
        return this.input.data[this.location.end_location.index];
    }
    nextChar() {
        const current_c = this.getChar();
        if (current_c === "\n") {
            this.location.end_location.line++;
            this.location.end_location.offset = 0;
        }
        else {
            this.location.end_location.offset++;
        }
        this.location.end_location.index++;
        return this.getChar();
    }
    isWhitespace(c) {
        return c === " " || c === "\t" || c === "\n" || c === "\r";
    }
    readWhitespace() {
        let has_tab = false;
        let has_line = false;
        let c = this.getChar();
        while (c !== null && this.isWhitespace(c)) {
            if (has_line === false && c === "\t")
                has_tab = true;
            if (has_line === false && c === "\n")
                has_line = true;
            c = this.nextChar();
        }
        return this.createToken(TokenType.T_WHITESPACE, {
            has_tab: has_tab,
            has_line: has_line
        });
    }
    isEOF() {
        return this.location.end_location.index >= this.input.data.length;
    }
}
class Ast {
    constructor() {
        this.kind = "";
    }
}
class AstStatement {
    constructor() {
        this.kind = "Statement";
    }
}
class AstEcho {
    constructor() {
        this.kind = "Echo";
    }
}
class AstTernaryExpression {
    constructor(condition, true_value, false_value) {
        this.kind = "TernaryExpression";
        this.condition = condition;
        this.true_value = true_value;
        this.false_value = false_value;
    }
}
class AstPostfixExpression {
    constructor(operator, operand) {
        this.kind = "PostfixExpression";
        this.operator = operator;
        this.operand = operand;
    }
}
class AstPrefixExpression {
    constructor(operator, right) {
        this.kind = "PrefixExpression";
        this.operator = operator;
        this.right = right;
    }
}
class AstExpression {
    constructor(expr) {
        this.kind = "Expression";
        this.expression = expr;
    }
}
class AstAssignmentExpression {
    constructor(operator, left, right) {
        this.kind = "AssignmentExpression";
        this.operator = operator;
        this.left = left;
        this.right = right;
    }
}
class AstIdentifier {
    constructor(name) {
        this.kind = "Identifier";
        this.name = name;
    }
}
class AstMemberExpression {
    constructor(object, property) {
        this.kind = "MemberExpression";
        this.object = object;
        this.property = property;
    }
}
class AstConditionalExpression {
    constructor(test, consequent, alternate) {
        this.kind = "ConditionalExpression";
        this.test = test;
        this.consequent = consequent;
        this.alternate = alternate;
    }
}
class AstUnaryExpression {
    constructor(operator, argument) {
        this.kind = "UnaryExpression";
        this.operator = operator;
        this.argument = argument;
    }
}
class AstIfStatement {
    constructor(test, consequent, alternate) {
        this.kind = "IfStatement";
        this.test = test;
        this.consequent = consequent;
        this.alternate = alternate;
    }
}
class AstLogicalExpression {
    constructor(operator, left, right) {
        this.kind = "LogicalExpression";
        this.operator = operator;
        this.left = left;
        this.right = right;
    }
}
class AstBinaryExpression {
    constructor(operator, left, right) {
        this.kind = "BinaryExpression";
        this.operator = operator;
        this.left = left;
        this.right = right;
    }
}
class AstCallExpression {
    constructor(callee, args) {
        this.kind = "CallExpression";
        this.callee = callee;
        this.arguments = args;
    }
}
class AstLiteralExpression {
    constructor(type, value) {
        this.kind = "LiteralExpression";
        this.type = type;
        this.value = value;
    }
}
class AstEmptyStatement {
    constructor() {
        this.kind = "EmptyStatement";
    }
}
class AstBlock {
    constructor(statements) {
        this.kind = "Block";
        this.statements = statements;
    }
}
class AstProgram {
    constructor(body, location) {
        this.kind = "Program";
        this.errors = [];
        this.body = body;
        this.location = location;
    }
}
class Parser {
    constructor(location, tokens) {
        this.index = 0;
        this.location = location;
        this.tokens = tokens;
    }
    isEOF() {
        return this.index >= this.tokens.length || this.frontType() === TokenType.T_EOF;
    }
    parse() {
        let statements = [];
        while (!this.isEOF()) {
            const ast = this.parseStatement();
            if (ast !== null)
                statements.push(ast);
        }
        return new AstProgram(statements, this.location);
    }
    parseIdentifier() {
        let ident = this.expect(TokenType.T_IDENTIFIER);
        this.skip(TokenType.T_WHITESPACE);
        if (this.skip(TokenType.T_OPERATOR_EQUAL)) {
            this.skip(TokenType.T_WHITESPACE);
            let expr = this.parseExpression();
            console.log(`define ${ident.value} = ${expr}`);
            return new AstAssignmentExpression("=", new AstIdentifier(ident.value), expr);
        }
        else if (this.skip(TokenType.T_OPERATOR_DOT)) {
            this.skip(TokenType.T_WHITESPACE);
            let expr = this.parseExpression();
            return new AstMemberExpression(new AstIdentifier(ident.value), expr);
        }
        else {
            return new AstIdentifier(ident.value);
        }
    }
    parseEcho() {
        this.expect(TokenType.T_ECHO);
        this.skip(TokenType.T_WHITESPACE);
        let expr = this.parseExpression();
        return new AstCallExpression(new AstIdentifier("echo"), [expr]);
    }
    parseExpressionLiteral() {
        const ft = this.frontType();
        if (ft === TokenType.T_NUMBER) {
            const t = this.expect(TokenType.T_NUMBER);
            return new AstLiteralExpression("number", t.value);
        }
        else {
            throw new Error(`Unexpected token ${ft}`);
        }
    }
    parseBlock() {
        if (this.skip(TokenType.T_SEMICOLON)) {
            return new AstEmptyStatement();
        }
        this.expect(TokenType.T_OPEN_BRACE);
        this.skip(TokenType.T_WHITESPACE);
        let statements = [];
        while (!this.isEOF() && !this.skip(TokenType.T_CLOSE_BRACE)) {
            const ast = this.parseStatement();
            if (ast !== null)
                statements.push(ast);
        }
        return new AstBlock(statements);
    }
    parseIf() {
        this.expect(TokenType.T_IF);
        this.skip(TokenType.T_WHITESPACE);
        let test = this.parseExpression();
        this.skip(TokenType.T_WHITESPACE);
        let consequent = this.parseBlock();
        this.skip(TokenType.T_WHITESPACE);
        let alternate = null;
        if (this.skip(TokenType.T_ELSE)) {
            this.skip(TokenType.T_WHITESPACE);
            if (this.has(TokenType.T_OPEN_BRACE) || this.has(TokenType.T_SEMICOLON)) {
                alternate = this.parseBlock();
            }
            else if (this.has(TokenType.T_IF)) {
                alternate = this.parseStatement();
            }
            else {
                throw new Error(`Unexpected token ${TokenType[this.frontType()]} in else statement`);
            }
        }
        return new AstIfStatement(test, consequent, alternate);
    }
    parseSubExpression() {
        this.skip(TokenType.T_PARENTHESIS_OPEN);
        this.skip(TokenType.T_WHITESPACE);
        let expr = this.parseExpression();
        this.skip(TokenType.T_WHITESPACE);
        this.skip(TokenType.T_PARENTHESIS_CLOSE);
        return expr;
    }
    expectOneOf(tokens) {
        let res = null;
        for (let i = 0; i < tokens.length; i++) {
            if (this.frontType() === tokens[i]) {
                res = this.front();
                this.goNextToken();
                break;
            }
        }
        if (res === null) {
            throw new Error(`Unexpected token ${TokenType[this.frontType()]}`);
            return null;
        }
        return res;
    }
    parsePrefixExpression(min_bp) {
        let operator = this.expectOneOf([
            TokenType.T_OPERATOR_PLUS,
            TokenType.T_OPERATOR_MINUS,
        ]);
        if (operator === null) {
            throw new Error(`Unexpected token ${this.frontType()}`);
        }
        const expr = this.parseExpression(min_bp);
        return new AstPrefixExpression(operator, expr);
    }
    // Look up the right binding power of a given prefix operator
    prefix_bp_lookup(whichOperator) {
        switch (whichOperator) {
            case TokenType.T_OPERATOR_PLUS: return 300;
            case TokenType.T_OPERATOR_MINUS: return 300;
            default: return 0;
        }
    }
    parsePostfixExpression(lhs) {
        let operator = this.expectOneOf([
            TokenType.T_OPERATOR_PLUS,
            TokenType.T_OPERATOR_MINUS,
        ]);
        if (operator === null) {
            throw new Error(`Unexpected token ${this.frontType()}`);
        }
        return new AstPostfixExpression(operator, lhs);
    }
    parseTernaryExpression(clause) {
        this.skip(TokenType.T_WHITESPACE);
        this.expect(TokenType.T_OPERATOR_QUESTION);
        this.skip(TokenType.T_WHITESPACE);
        let consequent = this.parseExpression(0);
        this.skip(TokenType.T_WHITESPACE);
        this.expect(TokenType.T_OPERATOR_COLON);
        this.skip(TokenType.T_WHITESPACE);
        let alternate = this.parseExpression(0);
        this.skip(TokenType.T_WHITESPACE);
        return new AstTernaryExpression(clause, consequent, alternate);
    }
    parseBinaryExpression(_lhs, min_bp) {
        let lhs = _lhs;
        let operator = this.expectOneOf([
            TokenType.T_OPERATOR_PLUS,
            TokenType.T_OPERATOR_MINUS,
        ]);
        if (operator === null) {
            throw new Error(`Unexpected token ${this.frontType()}`);
        }
        let rhs = this.parseExpression(min_bp);
        return new AstBinaryExpression(operator, lhs, rhs);
    }
    LeftAssociative(priority) {
        return { left_power: (priority - 1), right_power: priority };
    }
    RightAssociative(priority) {
        return { left_power: (priority + 1), right_power: priority };
    }
    bp_lookup(whichOperator) {
        const no_binding_power = { left_power: 0, right_power: 0 };
        switch (whichOperator) {
            case TokenType.T_OPERATOR_PLUS: return this.LeftAssociative(100);
            case TokenType.T_OPERATOR_MINUS: return this.LeftAssociative(100);
            case TokenType.T_OPERATOR_MULTIPLY: return this.LeftAssociative(200);
            case TokenType.T_OPERATOR_DIVIDE: return this.LeftAssociative(200);
            // case TokenType.T_POW: return this.LeftAssociative(99);
            case TokenType.T_OPERATOR_POWER: return this.RightAssociative(99);
            case TokenType.T_OPERATOR_QUESTION: return this.RightAssociative(1000);
            case TokenType.T_OPERATOR_GREATER: return this.LeftAssociative(50);
            case TokenType.T_OPERATOR_GREATER_EQUAL: return this.LeftAssociative(50);
            case TokenType.T_OPERATOR_LESS: return this.LeftAssociative(50);
            case TokenType.T_OPERATOR_LESS_EQUAL: return this.LeftAssociative(50);
            case TokenType.T_OPERATOR_EQUAL_EQUAL: return this.LeftAssociative(50);
            case TokenType.T_OPERATOR_NOT_EQUAL: return this.LeftAssociative(50);
            // --- Postfix --- (Always Right Associative)
            case TokenType.T_OPERATOR_BANG: return this.RightAssociative(400);
            //Note: Postfix operators are always RightAssociative
            default: return no_binding_power;
        }
    }
    parseExpression(binding_power_to_my_right = 0) {
        let result = null;
        const ft = this.frontType();
        if (ft === TokenType.T_NUMBER) {
            console.log("ft is number\n");
            result = this.parseExpressionLiteral();
        }
        else if (ft === TokenType.T_PARENTHESIS_OPEN) {
            result = this.parseSubExpression();
        }
        else if (ft === TokenType.T_IDENTIFIER) {
            return this.parseIdentifier();
        }
        else if (this.has(TokenType.T_OPERATOR_PLUS) || this.has(TokenType.T_OPERATOR_MINUS)) {
            result = this.parsePrefixExpression(this.prefix_bp_lookup(ft));
        }
        else {
            throw new Error(`Unexpected token ${TokenType[ft]}`);
        }
        console.log("Result is: ", result);
        assert(result != null); // We should always have either a LHS or Prefix Operator at this point.
        console.log(binding_power_to_my_right);
        console.log(this.bp_lookup(this.frontType()).left_power);
        while (binding_power_to_my_right < this.bp_lookup(this.frontType()).left_power) {
            // Is it a postfix expression?
            if (this.has(TokenType.T_OPERATOR_BANG)) {
                result = this.parsePostfixExpression(result);
            }
            else if (this.has(TokenType.T_OPERATOR_QUESTION)) {
                result = this.parseTernaryExpression(result);
            }
            else {
                // It must be a binary expression
                result = this.parseBinaryExpression(result, this.bp_lookup(this.frontType()).right_power);
            }
        }
        assert(result != null); // This factory should always return an expression tree fragment
        return result;
    }
    parseStatement() {
        const ft = this.frontType();
        if (ft === TokenType.T_WHITESPACE || ft === TokenType.T_SEMICOLON) {
            this.goNextToken();
            return null;
        }
        else if (ft === TokenType.T_IF) {
            return this.parseIf();
        }
        else if (ft === TokenType.T_ECHO) {
            return this.parseEcho();
        }
        else if (ft === TokenType.T_IDENTIFIER) {
            return this.parseExpression();
        }
        else {
            throw new Error(`Unexpected token ${TokenType[ft]}`);
        }
    }
    frontType() {
        // console.log(this.index, this.tokens[this.index]);
        return this.tokens[this.index].type;
    }
    front() {
        return this.tokens[this.index];
    }
    has(looking_for) {
        if (this.frontType() === looking_for) {
            return true;
        }
        return false;
    }
    skip(looking_for) {
        if (!this.isEOF() && this.frontType() === looking_for) {
            this.goNextToken();
            return true;
        }
        return false;
    }
    expect(looking_for) {
        let ft = this.frontType();
        if (ft !== looking_for) {
            throw new Error(`Expected ${TokenType[looking_for]} but got ${TokenType[ft]}`);
        }
        const f = this.front();
        this.goNextToken();
        return f;
    }
    goNextToken() {
        this.index++;
    }
}
function debug(value) {
    console.log(JSON.stringify(value, null, '\t'));
}
function main() {
    console.log(`Hello!`);
    // =============== Input =================
    // let input: Input = new Input("one.ts", ".");
    // input.readFile();
    let input = new Input();
    // const source_code = "echo             1234567890";
    // const source_code = "abc def ghi";
    // const source_code = "age = 50;echo age;";
    // const source_code = "age = 50;";
    // const source_code = "echo age;a.b.c";
    // const source_code = "echo age;a.b.c; age = 50;if(5>2){echo 1;}";//  else {echo 2;}";
    // const source_code = "if(5){echo 1;} else {echo 2;} if(5) ;";
    const source_code = "echo 110*10;";
    input.setData(source_code);
    console.log(input);
    // =============== Lexer =================
    const lexer = new Lexer(input);
    lexer.tokenize();
    console.log(lexer);
    // debug(lexer);
    // debug(lexer.tokens);
    // =============== Parser =================
    const parser = new Parser(lexer.location, lexer.tokens);
    const ast = parser.parse();
    // console.log(parser);
    // console.log(ast);
    debug(ast);
    // =============== AST =================
    // =============== Interpreter =================
    // =============== Compiler =================
    // =============== Code Generator =================
    // =============== Code Optimizer =================
    // =============== Code Compiler =================
    // =============== Code Runner =================
}
main();
